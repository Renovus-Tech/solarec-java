
package tech.renovus.solarec.inverters.brand.fimer.api.plantsGroups.info;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "plantGroupEntityID",
    "plantGroupName",
    "plantGroupState",
    "portfolioEID"
})
@Generated("jsonschema2pojo")
public class Result {

    @JsonProperty("plantGroupEntityID")
    private Integer plantGroupEntityID;
    @JsonProperty("plantGroupName")
    private String plantGroupName;
    @JsonProperty("plantGroupState")
    private String plantGroupState;
    @JsonProperty("portfolioEID")
    private Integer portfolioEID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("plantGroupEntityID")
    public Integer getPlantGroupEntityID() {
        return plantGroupEntityID;
    }

    @JsonProperty("plantGroupEntityID")
    public void setPlantGroupEntityID(Integer plantGroupEntityID) {
        this.plantGroupEntityID = plantGroupEntityID;
    }

    public Result withPlantGroupEntityID(Integer plantGroupEntityID) {
        this.plantGroupEntityID = plantGroupEntityID;
        return this;
    }

    @JsonProperty("plantGroupName")
    public String getPlantGroupName() {
        return plantGroupName;
    }

    @JsonProperty("plantGroupName")
    public void setPlantGroupName(String plantGroupName) {
        this.plantGroupName = plantGroupName;
    }

    public Result withPlantGroupName(String plantGroupName) {
        this.plantGroupName = plantGroupName;
        return this;
    }

    @JsonProperty("plantGroupState")
    public String getPlantGroupState() {
        return plantGroupState;
    }

    @JsonProperty("plantGroupState")
    public void setPlantGroupState(String plantGroupState) {
        this.plantGroupState = plantGroupState;
    }

    public Result withPlantGroupState(String plantGroupState) {
        this.plantGroupState = plantGroupState;
        return this;
    }

    @JsonProperty("portfolioEID")
    public Integer getPortfolioEID() {
        return portfolioEID;
    }

    @JsonProperty("portfolioEID")
    public void setPortfolioEID(Integer portfolioEID) {
        this.portfolioEID = portfolioEID;
    }

    public Result withPortfolioEID(Integer portfolioEID) {
        this.portfolioEID = portfolioEID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Result withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
