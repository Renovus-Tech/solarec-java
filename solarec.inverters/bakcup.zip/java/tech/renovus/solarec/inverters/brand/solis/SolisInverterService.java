package tech.renovus.solarec.inverters.brand.solis;

import java.util.Collection;

import tech.renovus.solarec.inverters.common.InverterService;
import tech.renovus.solarec.vo.db.data.ClientVo;
import tech.renovus.solarec.vo.db.data.GenDataVo;

public class SolisInverterService implements InverterService {

	@Override
	public Collection<GenDataVo> retrieveData(ClientVo client) {
		// TODO Auto-generated method stub
		return null;
	}

}
