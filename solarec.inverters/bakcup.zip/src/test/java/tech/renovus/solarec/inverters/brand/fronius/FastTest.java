package tech.renovus.solarec.inverters.brand.fronius;

import java.util.Collection;
import java.util.Date;

import tech.renovus.solarec.util.CollectionUtil;
import tech.renovus.solarec.vo.db.data.ClientVo;
import tech.renovus.solarec.vo.db.data.DataDefParameterVo;
import tech.renovus.solarec.vo.db.data.GenDataDefParameterVo;
import tech.renovus.solarec.vo.db.data.GenDataVo;
import tech.renovus.solarec.vo.db.data.GeneratorVo;
import tech.renovus.solarec.vo.db.data.LocationVo;

public class FastTest {

	private static GenDataDefParameterVo createParameter(String paramName, String paramValue) {
		DataDefParameterVo paramVo = new DataDefParameterVo();
		paramVo.setDataDefParName(paramName);
		
		GenDataDefParameterVo result = new GenDataDefParameterVo();
		result.setGenDataDefParValue(paramValue);
		result.setDataDefParameter(paramVo);
		
		return result;
	}
	
	public static void main(String... args) {
		String accessKeyId = "FKIA844B1E93211A41F8AD3D0EB0CCCE439F";
		String accessKeyValue = "4c224805-7fdf-4bf0-8fc4-651c36324d97";
		String pvSystemsIdToUse = "20bb600e-019b-4e03-9df3-a0a900cda689";

		FroniusInverterService service = new FroniusInverterService();
		
		GeneratorVo generator = new GeneratorVo();
		generator.add(createParameter(FroniusInverterService.PARAM_ACCESS_KEY_ID, accessKeyId));
		generator.add(createParameter(FroniusInverterService.PARAM_ACCESS_KEY_VALUE, accessKeyValue));
		generator.add(createParameter(FroniusInverterService.PARAM_GEN_PV_SYSTEM_ID, pvSystemsIdToUse));
		
		LocationVo location = new LocationVo();
		location.add(generator);
		
		ClientVo client = new ClientVo();
		client.add(location);
		
		Collection<GenDataVo> data = service.retrieveData(client);
		
		if (CollectionUtil.notEmpty(data)) {
			data.forEach(x -> System.out.println(x.getDataDate() + " - " + x.getDataTypeId() + " - " + x.getDataValue()));
		} else {
			System.out.println("!!!!! DATA IS EMPTY !!!!!!!!!!!!!!");
		}
		
		System.out.println("Next date to retrieve: " + new Date(Long.valueOf(generator.getDataDefParameterVo(FroniusInverterService.PARAM_GEN_LAST_DATE_RETRIEVE).getGenDataDefParValue())));
		
//		PvSystemsListResponse listResponse = service.getPvSystemsList(accessKeyId, accessKeyValue);
//		
//		System.out.println("List of available systems");
//		listResponse.getPvSystemIds().forEach(System.out::println);
//		
//		String pvSystemsId = listResponse.getPvSystemIds().iterator().next();
//		String pvSystemsIdToUse = "20bb600e-019b-4e03-9df3-a0a900cda689";
//		
//		System.out.println("System to use: " + pvSystemsIdToUse);
//		Calendar cal = Calendar.getInstance();
//		cal.add(Calendar.DAY_OF_YEAR, -1);
//		cal.set(Calendar.HOUR_OF_DAY, 0);
//		cal.set(Calendar.MINUTE, 0);
//		cal.set(Calendar.SECOND, 0);
//		cal.set(Calendar.MILLISECOND, 0);
//		cal.set(Calendar.AM_PM, Calendar.AM);
//		
//		cal.set(Calendar.YEAR, 2023);
//		cal.set(Calendar.MONTH, Calendar.DECEMBER);
//		cal.set(Calendar.DAY_OF_MONTH, 12);
//		
//		Date from = cal.getTime();
//		
//		int year = cal.get(Calendar.YEAR);
//		int month = cal.get(Calendar.MONTH) + 1;
//		int day = cal.get(Calendar.DAY_OF_MONTH);
//		
//		cal.add(Calendar.DAY_OF_YEAR, 1);
//		cal.add(Calendar.MILLISECOND, -1);
//		
//		Date to = cal.getTime();
//		
//		System.out.println("Getting aggregated data for: " + pvSystemsIdToUse);
//		System.out.println("Year: " + year);
//		System.out.println("Month: " + month);
//		System.out.println("Day: " + day);
//		
//		AggregatedSpecificDate aggregatedData = service.getPvSystemsAggredatedDataSpecificDate(accessKeyId, accessKeyValue, pvSystemsIdToUse, year, month, day);
//		System.out.println("Aggregated data retrieved: " + aggregatedData.getData().getChannels().size());
//		aggregatedData.getData().getChannels().forEach(x -> System.out.println(x.getChannelName() + " - " + x.getValues().getAdditionalProperties().get(Integer.toString(day)) + " " + x.getUnit()));
//		
//		
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
//		System.out.println("Getting history data for: " + pvSystemsIdToUse);
//		System.out.println("From: " + formatter.format(from));
//		System.out.println("To: " + formatter.format(to));
//		
//		HistoryDataResponse historyData = service.getPvSystemsHistData(accessKeyId, accessKeyValue, pvSystemsIdToUse, from, to);
//		
//		System.out.println("History data retrieved: " + historyData.getData().size());
//		historyData.getData().forEach(x -> System.out.println(x.getLogDateTime()));
	}
}
