package tech.renovus.solarec.inverters.brand.fimer;

import tech.renovus.solarec.inverters.brand.fimer.api.authenticate.AuthenticateResponse;
import tech.renovus.solarec.inverters.brand.fimer.api.ipRanges.datalogger.IpRangeDataloggerResponse;
import tech.renovus.solarec.inverters.brand.fimer.api.ipRanges.web.IpRangeWebResponse;
import tech.renovus.solarec.inverters.brand.fimer.api.organization.OrganizationResponse;
import tech.renovus.solarec.inverters.brand.fimer.api.status.StatusResponse;

public class FastTest {

	public static void main(String... args) {
		FimerInverterService service = new FimerInverterService();
		
		StatusResponse status = service.status();
		if (status == null) System.out.println("No status available");
		else System.out.println("Status: " + status.getResult());
		
		String user = "gerardo.lapetina ";
		String password = "Fimermx1!";
		String key = "23651c4c-ea24-4dbf-841c-f51fc82c47d1-0c81";
		
		AuthenticateResponse authentication = service.authenticate(user, password, key);
		System.out.println("Auth key: " + authentication.getResult());
		
		String authKey = authentication.getResult();
		
		IpRangeDataloggerResponse ipRangeDataLogger = service.getIpRangeDatalogger(authKey);
		System.out.println("Has ip range data logger: " + (ipRangeDataLogger != null));
		if (ipRangeDataLogger != null) ipRangeDataLogger.getResult().getPrefixes().forEach(System.out::println);
		
		IpRangeWebResponse ipRangeDataWeb = service.getIpRangeWeb(authKey);
		System.out.println("Has ip range web: " + (ipRangeDataWeb != null));
		if (ipRangeDataWeb != null) ipRangeDataWeb.getResult().getPrefixes().forEach(System.out::println);
		
		OrganizationResponse organization = service.getPortafolioGroup(authKey);
		System.out.println("Has organization: " + (organization != null));
		if (organization != null) System.out.println(organization.getResult().getPortfolioGroupName());
	}
}
